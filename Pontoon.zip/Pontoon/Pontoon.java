package com.bham.pij.assignments.pontoon;
// Sarina Saqib 2249047

public class Pontoon extends CardGame {

    public Pontoon(int nplayers) {

        super(nplayers);
        dealInitialCards();

    }

    @Override
    public void dealInitialCards() {

        for (Player player : players) {

            for (int i = 0; i < 2; i++) {
                player.dealToPlayer(getDeck().dealRandomCard());
            }

        }

    }

    public boolean pontoonHand(Player hand) {

        if (hand.getBestNumericalHandValue() == 21 && hand.getHandSize() == 2) {
            return true;
        } else
            return false;

    }

    public boolean bust(Player hand) {

        if (hand.getBestNumericalHandValue() > 21) {
            return true;
        } else
            return false;
    }

    public boolean fiveCardTrick(Player hand) {

        if (hand.getHandSize() == 5 && hand.getBestNumericalHandValue() <= 21) {
            return true;
        } else
            return false;
    }

    @Override
    public int compareHands(Player hand1, Player hand2) {
        int playerWins = 0;

        if (pontoonHand(hand1) == true && pontoonHand(hand2) == false) {
            playerWins = -1;
        } else {
            if (pontoonHand(hand2) == true && pontoonHand(hand1) == false) {
                playerWins = 1;
            } else {
                if (pontoonHand(hand1) == true && pontoonHand(hand2) == true) {
                    playerWins = 0;
                } else {
                    if (fiveCardTrick(hand1) == true && fiveCardTrick(hand2) == false) {
                        playerWins = -1;
                    } else {
                        if (fiveCardTrick(hand2) == true && fiveCardTrick(hand1) == false) {
                            playerWins = 1;
                        } else {
                            if (fiveCardTrick(hand1) == true && fiveCardTrick(hand2) == true) {
                                playerWins = 0;
                            } else {
                                if (fiveCardTrick(hand1) == false && pontoonHand(hand1) == false
                                        && fiveCardTrick(hand2) == false && pontoonHand(hand2) == false) {
                                    if (hand1.getBestNumericalHandValue() > hand2.getBestNumericalHandValue()
                                            && bust(hand1) == false) {
                                        playerWins = -1;
                                    }
                                } else {
                                    if (hand2.getBestNumericalHandValue() > hand1.getBestNumericalHandValue()
                                            && bust(hand2) == false) {
                                        playerWins = 1;
                                    } else {
                                        if (hand1.getBestNumericalHandValue() == hand2.getBestNumericalHandValue()) {
                                            playerWins = 0;
                                        }
                                    }

                                }

                            }

                        }

                    }
                }
            }

        }

        return playerWins;

    }

}