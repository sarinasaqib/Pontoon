package com.bham.pij.assignments.pontoon;
// Sarina Saqib 2249047

import java.util.ArrayList;

public abstract class CardGame {

    public ArrayList<Player> players = new ArrayList<Player>();
    private Deck deck;
    public int nplayers;

    public CardGame(int nplayers) {

        deck = new Deck();
        this.nplayers = nplayers;

        for (int i = 0; i < nplayers; i++) {
            players.add(new Player("Player" + i));
        }

    }

    public abstract void dealInitialCards();

    public abstract int compareHands(Player hand1, Player hand2);

    public Deck getDeck() {

        return deck;

    }

    public Player getPlayer(int i) {

        return players.get(i);

    }

    public int getNumPlayers() {

        return nplayers;

    }
}
