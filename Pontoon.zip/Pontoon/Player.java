package com.bham.pij.assignments.pontoon;
// Sarina Saqib 2249047

import java.util.ArrayList;
import java.util.Collections;

public class Player {

    private String name;
    private ArrayList<Card> hand = new ArrayList<Card>();
    private ArrayList<Integer> handSum;

    public Player(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void dealToPlayer(Card card) {
        hand.add(card);
    }

    public void removeCard(Card card) {
        hand.remove(card);
    }

    public ArrayList<Integer> getNumericalHandValue() {

        handSum = new ArrayList<Integer>();

        int total = 0;
        int total1;
        int total2;
        int total3;
        int total4;
        int total5;
        int total6;
        int total7;

        for (int i = 0; i < hand.size(); i++) {
            handSum.addAll(hand.get(i).getNumericalValue());
        }

        for (int value : handSum) {

            total = total + value;

        }

        int h = Collections.frequency(handSum, 1);
        int g = Collections.frequency(handSum, 11);

        if (h == 1 && g == 1) {
            total1 = total - 12;
            total2 = total1 + 1;
            total3 = total1 + 11;
            handSum.clear();
            handSum.add(total2);
            handSum.add(total3);
        } else if (h == 2 && g == 2) {
            total1 = total - 24;
            total2 = total1 + 1 + 1;
            total3 = total1 + 11 + 11;
            total4 = total1 + 1 + 11;
            handSum.clear();
            handSum.add(total2);
            handSum.add(total3);
            handSum.add(total4);
        } else if (h == 3 && g == 3) {
            total1 = total - 36;
            total2 = total1 + 1 + 1 + 1;
            total3 = total1 + 11 + 11 + 11;
            total4 = total1 + 1 + 11 + 11;
            total5 = total1 + 11 + 1 + 1;
            handSum.clear();
            handSum.add(total2);
            handSum.add(total3);
            handSum.add(total4);
            handSum.add(total5);
        } else if (h == 4 && g == 4) {
            total1 = total - 48;
            total2 = total1 + 1 + 1 + 1 + 1;
            total3 = total1 + 11 + 11 + 11 + 11;
            total4 = total1 + 1 + 11 + 11 + 11;
            total5 = total1 + 11 + 1 + 1 + 1;
            total6 = total1 + 1 + 11 + 1 + 11;
            handSum.clear();
            handSum.add(total2);
            handSum.add(total3);
            handSum.add(total4);
            handSum.add(total5);
            handSum.add(total6);
        } else if (h == 5 && g == 5) {
            total1 = total - 60;
            total2 = total1 + 1 + 1 + 1 + 1 + 1;
            total3 = total1 + 11 + 11 + 11 + 11 + 11;
            total4 = total1 + 1 + 11 + 11 + 11 + 11;
            total5 = total1 + 11 + 1 + 1 + 1 + 1;
            total6 = total1 + 1 + 11 + 1 + 11 + 11;
            total7 = total1 + 1 + 1 + 11 + 11 + 1;
            handSum.clear();
            handSum.add(total2);
            handSum.add(total3);
            handSum.add(total4);
            handSum.add(total5);
            handSum.add(total6);
            handSum.add(total7);

        } else {
            handSum.clear();
            handSum.add(total);
        }

        Collections.sort(handSum);

        return handSum;

    }

    public int getBestNumericalHandValue() {

        getNumericalHandValue();
        return handSum.get(handSum.size() - 1);

    }

    public ArrayList<Card> getCards() {
        return hand;

    }

    public int getHandSize() {
        int size = hand.size();
        return size;

    }

}
