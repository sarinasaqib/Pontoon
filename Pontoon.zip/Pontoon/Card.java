package com.bham.pij.assignments.pontoon;
// Sarina Saqib 2249047

import java.util.ArrayList;

public class Card {

    public static enum Suit {
        CLUBS, HEARTS, DIAMONDS, SPADES;
    }

    public static enum Value {
        ACE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING;
    }

    private Suit suit;
    private Value value;

    public Card(Suit suit, Value value) {
        this.value = value;
        this.suit = suit;
    }

    public Suit getSuit() {
        return suit;
    }

    public void setSuit(Suit suit) {
        this.suit = suit;
    }

    public Value getValue() {
        return value;
    }

    public void setValue(Value value) {
        this.value = value;
    }

    public ArrayList<Integer> getNumericalValue() {

        ArrayList<Integer> ace = new ArrayList<Integer>();

        if (value == Value.ACE) {
            ace.add(1);
            ace.add(11);
        } else if (value == Value.TWO) {
            ace.add(2);
        } else if (value == Value.THREE) {
            ace.add(3);
        } else if (value == Value.FOUR) {
            ace.add(4);
        } else if (value == Value.FIVE) {
            ace.add(5);
        } else if (value == Value.SIX) {
            ace.add(6);
        } else if (value == Value.SEVEN) {
            ace.add(7);
        } else if (value == Value.EIGHT) {
            ace.add(8);
        } else if (value == Value.NINE) {
            ace.add(9);
        } else if (value == Value.TEN) {
            ace.add(10);
        } else if (value == Value.JACK) {
            ace.add(10);
        } else if (value == Value.QUEEN) {
            ace.add(10);
        } else if (value == Value.KING) {
            ace.add(10);
        }
        return ace;

    }

}
