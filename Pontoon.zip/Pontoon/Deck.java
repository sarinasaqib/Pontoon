package com.bham.pij.assignments.pontoon;
// Sarina Saqib 2249047

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Deck {

    ArrayList<Card> deck;

    public Deck() {

        deck = new ArrayList<Card>();

        for (Card.Suit suitarr : Card.Suit.values()) {
            for (Card.Value valuearr : Card.Value.values()) {
                deck.add(new Card(suitarr, valuearr));
            }
        }

    }

    public void reset() {

        deck.clear();

        for (Card.Suit suitarr : Card.Suit.values()) {
            for (Card.Value valuearr : Card.Value.values()) {
                deck.add(new Card(suitarr, valuearr));
            }
        }

    }

    public void shuffle() {

        Collections.shuffle(deck);
    }

    public Card getCard(int i) {
        return deck.get(i);

    }

    public Card dealRandomCard() {

        Random random = new Random();
        int randcard = random.nextInt(deck.size());
        Card randomCard = deck.get(randcard);
        deck.remove(randcard);

        return randomCard;

    }

    public int size() {
        return deck.size();

    }

}
